# Comunión de Teresa

Primera demo de la lista de regalos.

## Importante
Esta primera versión es una DEMO: las reservas se guardan en el navegador mediante localStorage. Por tanto, todavía NO sincroniza las reservas entre distintos móviles.

Para la versión definitiva hay que conectar la página a una base de datos (por ejemplo Supabase) y publicarla en Vercel. Así, cuando una persona reserve un regalo, desaparecerá para todos los demás.

## Publicación
1. Crea un repositorio en GitHub.
2. Sube `index.html`.
3. Entra en Vercel y selecciona el repositorio.
4. Vercel lo publicará con una dirección `.vercel.app`.

Antes de compartir el enlace con la familia, sustituiremos los regalos de prueba por los reales y conectaremos las reservas a una base de datos.
